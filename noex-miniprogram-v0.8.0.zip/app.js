// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.8.0',  // 2026-09-09 取消登录墙：登录入口只放「我」页，用功能时才提醒；微信头像/昵称支持能力降级
    name: '断联日记 NOEX',
    build: 'softlogin-v8',
    /* 从功能页点「去登录」过来时置 true，me 页 onShow 消费掉并展开登录卡 */
    autoOpenLogin: false
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
