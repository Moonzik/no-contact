// pages/me/me.js
const storage = require('../../utils/storage.js');
const util = require('../../utils/util.js');
const user = require('../../utils/user.js');

Page({
  data: {
    day: 1,
    sub: '已坚持 1 天',
    startDate: '',
    exName: '',
    /* 登录态 */
    logged: false,
    avatar: '',
    nick: '',
    showLogin: false,
    tmpAvatar: '',
    tmpNick: '',
    showLogout: false,
    showGear: false,
    showClear: false,
    version: ''
  },

  onShow() {
    /* 未登录一律拦到登录墙 */
    if (user.guardLogin()) return;
    this.refresh();
    /* 版本号从 app.globalData 读，避免关于页硬编码落后于真实版本 */
    this.setData({ version: this.readVersion() });
  },

  /* 测试环境可能没有 getApp，做防御 */
  readVersion() {
    try {
      if (typeof getApp === 'function') {
        const app = getApp();
        if (app && app.globalData && app.globalData.version) {
          return app.globalData.version;
        }
      }
    } catch (e) {
      /* ignore */
    }
    return '';
  },

  onMidnightRefresh() {
    this.refresh();
  },

  refresh() {
    const S = storage.load();
    const d = util.dayNum(S.startDate);
    const u = S.user || null;
    const avatar = (u && u.avatar) || '';
    const nick = (u && u.nick) || '';
    this.setData({
      day: d,
      sub: '已坚持 ' + d + ' 天',
      startDate: S.startDate,
      exName: S.exName,
      avatar: avatar,
      nick: nick || '断联中',
      logged: !!(nick || avatar)
    });
  },

  onPickDate(e) {
    this.setData({ startDate: e.detail.value });
    const S = storage.load();
    if (e.detail.value) {
      S.startDate = e.detail.value;
      storage.save(S);
      wx.showToast({ title: '已更新', icon: 'none' });
      this.refresh();
    }
  },

  onExInput(e) {
    const S = storage.load();
    S.exName = e.detail.value;
    storage.save(S);
  },

  /* ── 微信登录 / 编辑资料 ───────────────────────────── */

  onEditProfile() {
    const S = storage.load();
    const u = S.user || {};
    this.setData({
      showLogin: true,
      tmpAvatar: u.avatar || '',
      tmpNick: u.nick || ''
    });
  },

  /* button open-type="chooseAvatar" 的回调：拿到的是临时文件，要转存 */
  onChooseAvatar(e) {
    const url = e && e.detail && e.detail.avatarUrl;
    if (!url) return;
    const old = this.data.tmpAvatar;
    user.saveAvatar(url, old, (p) => {
      this.setData({ tmpAvatar: p });
    });
  },

  onNickInput(e) {
    this.setData({ tmpNick: (e && e.detail && e.detail.value) || '' });
  },

  onProfileSave() {
    const raw = this.data.tmpNick || '';
    const avatar = this.data.tmpAvatar || '';
    if (!avatar && !raw.replace(/\s/g, '')) {
      wx.showToast({ title: '选个头像或填个昵称', icon: 'none' });
      return;
    }
    const S = storage.load();
    const prevAvatar = (S.user && S.user.avatar) || '';
    if (prevAvatar && prevAvatar !== avatar) user.removeFile(prevAvatar);

    S.user = {
      nick: user.cleanNick(raw) || '断联中',
      avatar: avatar,
      loginAt: Date.now(),
      viaWx: false
    };
    storage.save(S);
    this.setData({ showLogin: false });
    wx.showToast({ title: '已登录', icon: 'none' });
    this.refresh();

    /* 走一次微信登录确认身份；将来接了服务器，在这里把 code 换成 openid 即可 */
    user.silentLogin((ok) => {
      if (!ok) return;
      const S2 = storage.load();
      if (S2.user) { S2.user.viaWx = true; storage.save(S2); }
    });
  },

  onProfileClose() {
    this.setData({ showLogin: false });
  },

  onLogoutAsk() {
    this.setData({ showLogin: false, showLogout: true });
  },

  onLogoutCancel() {
    this.setData({ showLogout: false });
  },

  onLogoutConfirm() {
    const S = storage.load();
    user.clearAvatar((S.user && S.user.avatar) || '');
    S.user = null;
    storage.save(S);
    this.setData({ showLogout: false });
    wx.showToast({ title: '已退出登录', icon: 'none' });
    /* 退出后回到登录墙：不登录就进不去任何页面 */
    setTimeout(() => {
      wx.reLaunch({ url: user.LOGIN_PAGE });
    }, 600);
  },

  /* ── 数据 ───────────────────────────── */

  onExport() {
    const S = storage.load();
    const json = storage.exportJson(S);
    /* 小程序里没法直接下载，复制到剪贴板让用户粘贴 */
    wx.setClipboardData({
      data: json,
      success: () => {
        wx.showToast({ title: '已复制 JSON 到剪贴板', icon: 'none' });
      }
    });
  },

  onClear() {
    this.setData({ showClear: true });
  },

  onClearConfirm() {
    const S = storage.load();
    user.clearAvatar((S.user && S.user.avatar) || '');
    Object.assign(S, storage.defaultState());
    S.startDate = util.todayStr();
    S.onboarded = false;
    S.user = null;
    storage.save(S);
    this.setData({ showClear: false });
    wx.showToast({ title: '已清空，重新开始', icon: 'none' });
    /* 退出后回 onboard */
    wx.reLaunch({ url: '/pages/onboard/onboard' });
  },

  onClearCancel() {
    this.setData({ showClear: false });
  },

  onGear() {
    this.setData({ showGear: true });
  },

  onCloseGear() {
    this.setData({ showGear: false });
  },

  /* 跳转微信托管的《用户隐私保护指引》——审核要求在小程序内可触达 */
  onOpenPrivacy() {
    if (typeof wx.openPrivacyContract === 'function') {
      wx.openPrivacyContract({
        fail: () => {
          wx.showToast({ title: '暂无法打开，请稍后重试', icon: 'none' });
        }
      });
    } else {
      wx.showToast({ title: '当前基础库版本不支持', icon: 'none' });
    }
  },

  /* wxml 里 catchtap="noop" 的空处理器（弹窗内层阻止冒泡用） */
  noop() {}
});
