// pages/login/login.js — 登录墙：未登录时任何页面都会跳到这里
const storage = require('../../utils/storage.js');
const user = require('../../utils/user.js');

Page({
  data: {
    avatar: '',
    nick: '',
    logging: false
  },

  onLoad() {
    /* 已经登录了就别拦着自己，直接回首页 */
    if (user.isLogged()) {
      wx.switchTab({ url: '/pages/today/today' });
    }
  },

  onChooseAvatar(e) {
    const url = e && e.detail && e.detail.avatarUrl;
    if (!url) return;
    const old = this.data.avatar;
    user.saveAvatar(url, old, (p) => {
      this.setData({ avatar: p });
    });
  },

  onNickInput(e) {
    this.setData({ nick: (e && e.detail && e.detail.value) || '' });
  },

  onLogin() {
    if (this.data.logging) return;
    if (!this.data.avatar) {
      wx.showToast({ title: '先选个头像', icon: 'none' });
      return;
    }
    this.setData({ logging: true });

    const avatar = this.data.avatar;
    const nick = user.cleanNick(this.data.nick) || '断联中';

    /* 先走微信登录，拿到凭证才算"成功登录" */
    user.silentLogin((ok) => {
      if (!ok) {
        this.setData({ logging: false });
        wx.showToast({ title: '登录失败，请重试', icon: 'none' });
        return;
      }
      const S = storage.load();
      const prevAvatar = (S.user && S.user.avatar) || '';
      if (prevAvatar && prevAvatar !== avatar) user.removeFile(prevAvatar);
      S.user = { nick: nick, avatar: avatar, loginAt: Date.now(), viaWx: true };
      storage.save(S);

      wx.showToast({ title: '登录成功', icon: 'none' });
      wx.switchTab({ url: '/pages/today/today' });
    });
  },

  noop() {}
});
