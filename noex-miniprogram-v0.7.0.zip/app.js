// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.7.0',  // 2026-09-08 强制微信登录 + 首页每日一句/今日肯定 + 小白/影子回复全局去重 + 聊天输入框常驻底部
    name: '断联日记 NOEX',
    build: 'login-daily-v7'
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
