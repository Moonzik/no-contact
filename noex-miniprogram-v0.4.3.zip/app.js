// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.4.3',  // 2026-09-08 影子导入体验修复：选文件失败不再静默 + 说明微信不能自动读聊天记录 + 粘贴扶正为主路径
    name: '断联日记 NOEX',
    build: 'shadow-import-ux-v7'
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
