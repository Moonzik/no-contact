// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.6.0',  // 2026-09-08 个人主页：微信登录（头像昵称填写能力）+ 排版精简 + 去掉性格选择
    name: '断联日记 NOEX',
    build: 'login-v6'
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
