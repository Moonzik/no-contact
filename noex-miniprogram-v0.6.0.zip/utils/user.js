// utils/user.js — 微信登录（头像昵称填写能力 + wx.login 静默凭证）
//
// 说明：本小程序没有服务器，做不了「code 换 openid」的账号体系。
// 这里的「微信登录」分两步，都是纯本地：
//   1) wx.login 拿到临时登录凭证 code → 只取成功与否，记录 loginAt（不外传，理由见下）
//   2) button open-type="chooseAvatar" + input type="nickname"
//      → 真正拿到微信头像和昵称，用户能直接看到
// 数据仍然全部只存在本机，和以前一样。

const AVATAR_PREFIX = 'noex_avatar_';
/* 自增序号：同一毫秒内连续换头像也不会撞文件名（撞了就不会删旧文件了） */
let avatarSeq = 0;

/* 微信给的是临时文件（wxfile://tmp_xxx），小程序重启后会被清掉。
   必须复制到 USER_DATA_PATH 才能长期显示。 */
function userDir() {
  try {
    return (typeof wx !== 'undefined' && wx.env && wx.env.USER_DATA_PATH) || '';
  } catch (e) {
    return '';
  }
}

function fsManager() {
  try {
    if (typeof wx === 'undefined' || typeof wx.getFileSystemManager !== 'function') return null;
    return wx.getFileSystemManager();
  } catch (e) {
    return null;
  }
}

/* 删除单个文件，失败静默（文件不存在也算成功） */
function removeFile(p) {
  if (!p) return;
  const fs = fsManager();
  if (!fs || typeof fs.unlink !== 'function') return;
  try {
    fs.unlink({ filePath: p, fail: () => {} });
  } catch (e) { /* ignore */ }
}

/* 把临时头像存到永久目录，回调返回最终可用的路径 */
function saveAvatar(tempPath, oldPath, cb) {
  const done = (finalPath) => { if (typeof cb === 'function') cb(finalPath || ''); };

  if (!tempPath) { done(''); return; }
  const dir = userDir();
  const fs = fsManager();

  /* 没有文件系统能力（非真机/测试环境）时，退回临时路径，保证 UI 不崩 */
  if (!dir || !fs || typeof fs.saveFile !== 'function') { done(tempPath); return; }

  const dest = dir + '/' + AVATAR_PREFIX + Date.now() + '_' + (++avatarSeq) + '.png';
  try {
    fs.saveFile({
      tempFilePath: tempPath,
      filePath: dest,
      success: () => {
        if (oldPath && oldPath !== dest) removeFile(oldPath);
        done(dest);
      },
      fail: () => { done(tempPath); }
    });
  } catch (e) {
    done(tempPath);
  }
}

/* wx.login：只用来确认「这是微信环境 + 用户已授权登录态」。
   code 有效期 5 分钟，存着没有意义（还会误导），所以只记时间戳。
   将来接了服务器，把 code 传给后端换 openid 即可，改这里一处。 */
function silentLogin(cb) {
  const done = (ok) => { if (typeof cb === 'function') cb(!!ok); };
  try {
    if (typeof wx === 'undefined' || typeof wx.login !== 'function') { done(false); return; }
    wx.login({
      timeout: 8000,
      success: (r) => { done(r && r.code); },
      fail: () => { done(false); }
    });
  } catch (e) {
    done(false);
  }
}

/* 退出登录：清掉头像文件 */
function clearAvatar(avatarPath) {
  removeFile(avatarPath);
}

/* 昵称清洗：去首尾空格、限长，避免空昵称 / 超长昵称把排版撑坏 */
function cleanNick(n) {
  const s = (n || '').toString().replace(/\s+/g, ' ').trim();
  return s.slice(0, 16);
}

module.exports = {
  AVATAR_PREFIX,
  userDir,
  saveAvatar,
  removeFile,
  silentLogin,
  clearAvatar,
  cleanNick
};
