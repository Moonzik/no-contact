// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.8.1',  // 2026-09-09 小白回复针对用户原话（意图打分制 + 接话复述 + 日常意图）+ 头像正圆 + 微信头像点不动的兜底
    name: '断联日记 NOEX',
    build: 'reply-v81',
    /* 从功能页点「去登录」过来时置 true，me 页 onShow 消费掉并展开登录卡 */
    autoOpenLogin: false
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
