// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.3.0',  // 2026-09-06 毒舌人格全面升级 (24 条池 + SHARP_REPLY 22 条)
    name: '断联日记 NOEX',
    build: 'poison-v3'
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
