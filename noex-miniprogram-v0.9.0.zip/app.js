// app.js — 全局入口
const storage = require('./utils/storage.js');
const ai = require('./utils/ai.js');

App({
  globalData: {
    version: '0.9.0',  // 2026-09-09 AI 智能体接入层：小白/影子可接大模型（默认关闭，不配就用本地引擎）+ 影子语言指纹（按发言人分离 + 真实原话样本）+ 影子聊天区布局修复
    name: '断联日记 NOEX',
    build: 'ai-agent-v9',
    /* 从功能页点「去登录」过来时置 true，me 页 onShow 消费掉并展开登录卡 */
    autoOpenLogin: false
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
