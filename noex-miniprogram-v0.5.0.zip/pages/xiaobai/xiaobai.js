// pages/xiaobai/xiaobai.js
const storage = require('../../utils/storage.js');
const util = require('../../utils/util.js');
const guardian = require('../../utils/guardian.js');

const CHIPS = ['我想ta了', '睡不着', '今天差点想联系ta', '我就是想说说'];

Page({
  data: {
    agentImg: '/images/agent.png',
    personas: [],
    personaOn: '',
    personaDesc: '',
    msgs: [],
    text: '',
    chips: CHIPS,
    status: '一直都在',
    day: 1,
    crisis: false,
    crisisText: ''
  },

  _msgSeq: 0,

  onLoad() {
    console.log('[xiaobai] onLoad, build = bugfix-sweep-v5');
  },

  onShow() {
    this.refresh();
  },

  onMidnightRefresh() {
    this.refresh();
  },

  refresh() {
    const S = storage.load();
    const personas = Object.keys(guardian.PERSONAS).map((k) => ({
      k,
      name: guardian.PERSONAS[k].name,
      desc: guardian.PERSONAS[k].desc,
      on: S.persona === k
    }));

    const msgs = S.gMsgs.map((m, i) => {
      const f = this.fmtMsg(m);
      f._k = i; /* 稳定渲染 key（原 wx:key="t"，但 fmtMsg 根本没返回 t） */
      return f;
    });
    /* 首次进入给个开场 */
    if (msgs.length === 0) {
      const introText = '我是小白。这里说的话不会去任何地方——你可以不坚强，也可以说不清楚。今天，是第 ' + util.dayNum(S.startDate) + ' 天。';
      msgs.push({ role: 'ai', avatar: this.data.agentImg, text: introText, _k: 0 });
      S.gMsgs.push({ role: 'ai', text: introText, t: Date.now() });
      storage.save(S);
    }
    this._msgSeq = msgs.length;

    this.setData({
      personas,
      personaOn: S.persona,
      personaDesc: guardian.PERSONAS[S.persona].desc,
      msgs,
      day: util.dayNum(S.startDate)
    });
  },

  fmtMsg(m) {
    if (m.role === 'sys') {
      return { role: 'sys', text: m.text };
    }
    if (m.role === 'ai') {
      return {
        role: 'ai',
        avatar: this.data.agentImg,
        text: m.text,
        tip: m.tip || ''
      };
    }
    return { role: 'me', text: m.text };
  },

  onPickPersona(e) {
    const k = e.currentTarget.dataset.k;
    const S = storage.load();
    if (S.persona !== k) {
      S.persona = k;
      S.gMsgs.push({
        role: 'sys',
        text: '（小白换了一种语气：「' + guardian.PERSONAS[k].name + '」）',
        t: Date.now()
      });
      storage.save(S);
    }
    this.refresh();
    this.scrollToBottom();
  },

  onInput(e) {
    this.setData({ text: e.detail.value || '' });
  },

  onBlur(e) {
    /* 失焦时也同步一次，防止某些机型 bindinput 漏触发 */
    if (e && e.detail && typeof e.detail.value === 'string') {
      this.setData({ text: e.detail.value });
    }
  },

  onTapChip(e) {
    const c = e.currentTarget.dataset.c;
    this.send(c);
  },

  onSend(e) {
    /* form submit 兜底：即使 textarea 的 bindinput 没触发，
       也能从 form 拿不到 value，所以仍然读 this.data.text */
    console.log('[xiaobai] onSend, data.text =', JSON.stringify(this.data.text));
    this.send(this.data.text);
  },

  send(rawText) {
    const text = (rawText || '').trim();
    if (!text) {
      wx.showToast({ title: '说点什么吧', icon: 'none', duration: 1200 });
      return;
    }

    const S = storage.load();
    S.gMsgs.push({ role: 'me', text, t: Date.now() });
    storage.save(S);
    this.setData({ text: '' });

    /* 把 me 消息 + 打字占位一起 push 到页面，缺一会导致用户看不到自己发的字 */
    const meMsg = { role: 'me', text, _k: this._msgSeq++ };
    const typingMsg = {
      role: 'ai-temp',
      avatar: this.data.agentImg,
      text: '',
      _k: this._msgSeq++
    };
    const msgs = this.data.msgs.concat([meMsg, typingMsg]);
    this.setData({ msgs });
    this.scrollToBottom();

    const reply = guardian.guardianReply(text, S.persona, S.bottle);

    setTimeout(() => {
      /* 重新读一次：闭包里的 S 是旧快照，连发两条会互相覆盖丢消息 */
      const S2 = storage.load();
      const filtered = this.data.msgs.filter((m) => m.role !== 'ai-temp');
      if (reply.crisis) {
        filtered.push({
          role: 'ai',
          avatar: this.data.agentImg,
          text: reply.text,
          _k: this._msgSeq++
        });
        S2.gMsgs.push({ role: 'ai', text: reply.text, t: Date.now() });
        storage.save(S2);
        this.setData({ msgs: filtered, crisis: true, crisisText: this.getCrisisText() });
      } else {
        filtered.push({
          role: 'ai',
          avatar: this.data.agentImg,
          text: reply.text,
          _k: this._msgSeq++
        });
        S2.gMsgs.push({ role: 'ai', text: reply.text, t: Date.now() });
        storage.save(S2);
        this.setData({ msgs: filtered });
      }
      this.scrollToBottom();
    }, 700 + Math.random() * 600);
  },

  getCrisisText() {
    return '请让真实的人现在陪着你\n\n' +
      '· 全国 24 小时心理援助热线：400-161-9995\n' +
      '· 北京心理危机研究与干预中心：010-82951332\n' +
      '· 紧急情况请直接拨打 120 / 110\n\n' +
      '你的痛苦是真实的，值得被认真对待。小白在乎你，但此刻你更需要身边的具体的人。';
  },

  onCloseCrisis() {
    this.setData({ crisis: false, crisisText: '' });
  },

  /* wxml 里 catchtap="noop" 的空处理器（弹窗内层阻止冒泡用） */
  noop() {},

  scrollToBottom() {
    /* 异步等 DOM 更新 */
    setTimeout(() => {
      wx.pageScrollTo({
        scrollTop: 99999,
        duration: 120
      });
    }, 30);
  }
});
