// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.5.0',  // 2026-09-08 毒舌大改版：sharp 走专属毒舌主池(不再复用温柔 base) + 影子支持剪贴板一键导入 + 修复输入框遮字
    name: '断联日记 NOEX',
    build: 'sharp-v5'
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
