// app.js — 全局入口
const storage = require('./utils/storage.js');

App({
  globalData: {
    version: '0.4.2',  // 2026-09-08 真机/兼容/审核专项：主包瘦身 1.31MB、隐私接口声明、iOS 日期解析加固、居中字距偏移修正
    name: '断联日记 NOEX',
    build: 'platform-review-v6'
  },

  onLaunch() {
    // 跨天检查：挂机过午夜后回到 today 页时自动刷新
    storage.initSessionTimer();
    console.log('[断联日记] 启动, 版本', this.globalData.version, this.globalData.build);
  },

  onShow() {}
});
