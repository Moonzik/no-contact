// pages/yingzi/yingzi.js
const storage = require('../../utils/storage.js');
const util = require('../../utils/util.js');
const guardian = require('../../utils/guardian.js');
const shadow = require('../../utils/shadow.js');
const wechat = require('../../utils/wechat.js');

Page({
  data: {
    mode: 'view', // view | setup | analyze | chat
    agentImg: '/images/agent.png',

    /* setup */
    shName: '',
    shLog: '',
    shFile: '',
    shSpeakers: [],
    shSel: '',
    shParseInfo: '',

    /* analyze */
    analyzeStep: 0,
    analyzeSteps: ['正在读取聊天记录…', '识别口头禅与语气词…', '分析回复节奏…', '生成影子…'],

    /* view (enabled) */
    shadowName: '',
    profileText: '',
    used: 0,
    maxDay: shadow.SHADOW_MAX_DAY,
    canEnter: true,

    /* chat */
    msgs: [],
    remain: '--:--',
    text: '',
    leftToday: 0,
    remainingSessionMs: shadow.SHADOW_MS,

    /* session-end 提示 */
    sessionEnd: false,

    /* crisis */
    crisis: false,
    crisisText: '',

    /* v0.4.0 · 温水冷却 + 自我洞察 */
    affinity: 80,        // 0-100，不进 UI，纯内部
    affinityText: '',    // 用户能看到的阶段文案（不显示数字）
    showReveal: false,   // 自我洞察面板可见性
    reveal: null         // { reason, text, secondary, options }
  },

  _tyingTimer: null,
  _userCount: 0,
  _parseCache: null,
  _msgSeq: 0,

  onShow() {
    this.refresh();
  },

  onUnload() {
    if (this._tyingTimer) clearInterval(this._tyingTimer);
  },

  refresh() {
    const S = storage.load();
    /* 聊天进行中切 tab 再回来：恢复聊天界面，而不是踢回 view（否则用户丢会话） */
    if (this.data.mode === 'chat' && S.shadow.sessionStart > 0) {
      this.renderChat();
      return;
    }
    const used = this.utilShadowSessionsToday(S);
    const canEnter = used < shadow.SHADOW_MAX_DAY;
    /* v0.4.0 · 温水冷却相似度计算 */
    const affinity = shadow.computeAffinity(S.shadow.firstUsedAt, S.shadow.totalShadowSessions);
    const affinityText = S.shadow.enabled ? shadow.affinityStageText(affinity) : '';
    this.setData({
      mode: 'view',
      shadowName: S.shadow.name || '',
      profileText: S.shadow.profile ? shadow.profileSummary(S.shadow.profile) : '',
      used,
      canEnter,
      affinity,
      affinityText,
      shName: S.shadow.name || S.exName || ''
    });
    /* v0.4.0 · 自我洞察：7 天未使用 / 满 30 天 → 打开影子页时就温和触发
       （此前只在 onEnterChat 里查，且 lastUsedAt 已被重置，no_use 永远不会触发） */
    if (S.shadow.enabled && !S.shadow.revealTriggered && S.shadow.firstUsedAt > 0) {
      const reveal = shadow.shouldReveal(S.shadow);
      if (reveal) this.fireReveal(reveal);
    }
  },

  utilShadowSessionsToday(S) {
    const sh = S.shadow;
    if (sh.sessionsDate !== util.todayStr()) {
      sh.sessionsDate = util.todayStr();
      sh.sessionsToday = 0;
      /* 必须保存整个 S。之前误存 sh（shadow 子对象）会把根状态整个覆盖，
         导致 onboarded/startDate/gMsgs/bottle 全部丢失 —— P0 级数据毁灭 bug */
      storage.save(S);
    }
    return sh.sessionsToday;
  },

  /* view → setup */
  onStart() {
    const S = storage.load();
    this.setData({
      mode: 'setup',
      shName: S.shadow.name || S.exName || '',
      shLog: '',
      shFile: '',
      shSpeakers: [],
      shSel: '',
      shParseInfo: ''
    });
  },

  onNameInput(e) {
    this.setData({ shName: e.detail.value });
  },

  onLogInput(e) {
    this.setData({ shLog: e.detail.value });
  },

  /* 从微信选择聊天记录文件 */
  onPickFile() {
    const self = this;
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      success: (res) => {
        const f = (res.tempFiles && res.tempFiles[0]) || {};
        const path = f.path;
        const name = f.name || '文件';
        if (!path) {
          wx.showToast({ title: '没有拿到文件路径', icon: 'none' });
          return;
        }
        if (!/\.(txt|html|htm|log|csv)$/i.test(name)) {
          wx.showToast({ title: '请选 txt 或 html', icon: 'none' });
          return;
        }
        self.setData({ shFile: '正在读取 ' + name + '…' });
        const fs = wx.getFileSystemManager();
        fs.readFile({
          filePath: path,
          success: (r) => {
            try {
              const text = wechat.decodeChatFile(r.data);
              const result = wechat.parseWeChatLog(text);
              self._parseCache = result;
              const sel = wechat.defaultShadowSpeaker(result);
              const content = sel
                ? (result.byName[sel] || []).join('\n')
                : result.cleaned;
              const cnt = content
                ? content.split(/\n+/).filter(Boolean).length
                : 0;
              self.setData({
                shLog: content,
                shFile: name + ' · 读到 ' + cnt + ' 条消息',
                shSpeakers: ['全部'].concat(result.speakers),
                shSel: sel || ''
              });
              if (!content || content.trim().length < 20) {
                wx.showToast({ title: '文件内容较少，建议直接粘贴', icon: 'none' });
              }
            } catch (e) {
              self.setData({ shFile: '解析失败，试试直接粘贴' });
              wx.showToast({ title: '解析失败：' + (e.message || ''), icon: 'none' });
            }
          },
          fail: () => {
            self.setData({ shFile: '读取失败，试试直接粘贴' });
          }
        });
      },
      fail: () => {
        // 用户取消，不报错
      }
    });
  },

  onPickSpeaker(e) {
    const sp = e.currentTarget.dataset.sp;
    const r = this._parseCache;
    if (!r) return;
    const content =
      sp === '全部' || !r.byName[sp] ? r.cleaned : r.byName[sp].join('\n');
    this.setData({ shSel: sp, shLog: content });
  },

  /* setup → analyze */
  onGoAnalyze() {
    const log = (this.data.shLog || '').trim();
    const name = (this.data.shName || '').trim();
    if (log.length < 20) {
      wx.showToast({ title: '多粘贴一些聊天记录，至少几行', icon: 'none' });
      return;
    }
    const S = storage.load();
    S.shadow.name = name || '影子';
    storage.save(S);
    this.setData({
      mode: 'analyze',
      analyzeStep: 0
    });
    this.runAnalyze(log);
  },

  runAnalyze(log) {
    const self = this;
    const steps = this.data.analyzeSteps;
    let i = 0;
    const tick = setInterval(() => {
      i++;
      if (i < steps.length) {
        self.setData({ analyzeStep: i });
      } else {
        clearInterval(tick);
        const S = storage.load();
        S.shadow.profile = shadow.analyzeChat(log);
        S.shadow.enabled = true;
        storage.save(S);
        self.setData({ mode: 'view' });
        wx.showToast({ title: '影子已生成', icon: 'none' });
        self.refresh();
      }
    }, 700);
  },

  onCancelSetup() {
    this.setData({ mode: 'view' });
  },

  /* view(enabled) → chat */
  onEnterChat() {
    const S = storage.load();
    const used = S.shadow.sessionsToday || 0;
    if (used >= shadow.SHADOW_MAX_DAY) {
      wx.showToast({ title: '今天影子次数用完了', icon: 'none' });
      return;
    }
    const now = Date.now();
    /* v0.4.0 · 自我洞察检测 —— 必须在重置 lastUsedAt 之前检查，
       否则 no_use（连续 7 天未用）永远不会触发 */
    const reveal = shadow.shouldReveal(S.shadow, now);
    if (reveal) {
      this.fireReveal(reveal);
      return;
    }
    /* v0.4.0 · 记录温水冷却数据 */
    if (!S.shadow.firstUsedAt || S.shadow.firstUsedAt <= 0) {
      S.shadow.firstUsedAt = now;
    }
    S.shadow.totalShadowSessions = (S.shadow.totalShadowSessions || 0) + 1;
    if (!S.shadow.observation || typeof S.shadow.observation !== 'object') {
      S.shadow.observation = { lastUsedAt: 0, daysWithNoUse: 0, userSaidNotLikeTa: 0, recentMsgAvgLen: 0 };
    }
    S.shadow.observation.lastUsedAt = now;
    S.shadow.observation.daysWithNoUse = 0;

    S.shadow.sessionsToday = used + 1;
    S.shadow.sessionStart = now;
    S.shadow.msgs = [];
    storage.save(S);
    /* 当前相似度传到 chat 用 */
    const affinity = shadow.computeAffinity(S.shadow.firstUsedAt, S.shadow.totalShadowSessions, now);
    this.setData({
      mode: 'chat',
      text: '',
      remainingSessionMs: shadow.SHADOW_MS,
      affinity,
      affinityText: shadow.affinityStageText(affinity)
    });
    this.renderChat();
  },

  onResetShadow() {
    wx.showModal({
      title: '关闭影子？',
      content: '已有的影子资料和记录会被删除。',
      confirmText: '删除影子',
      cancelText: '先留着',
      success: (res) => {
        if (res.confirm) {
          const S = storage.load();
          const def = storage.defaultState().shadow;
          S.shadow = def;
          storage.save(S);
          this.refresh();
          wx.showToast({ title: '影子已关闭', icon: 'none' });
        }
      }
    });
  },

  /* chat */
  renderChat() {
    const S = storage.load();
    const remain = Math.max(0, shadow.SHADOW_MS - (Date.now() - (S.shadow.sessionStart || Date.now())));
    const left = shadow.SHADOW_MAX_DAY - (S.shadow.sessionsToday || 0);
    let msgs = (S.shadow.msgs || []).map((m, i) => {
      const f = this.fmtMsg(m);
      f._k = i; /* 稳定的渲染 key（避免 wx:key="t" 时间戳重复） */
      return f;
    });
    if (msgs.length === 0) {
      const intro1 = {
        role: 'sys',
        text:
          '（这是根据聊天记录生成的 AI 影子，不是真的' +
          (S.shadow.name || '') +
          '。它不会主动找你，也不会替ta做任何承诺。）'
      };
      const intro2 = { role: 'ai', avatar: this.data.agentImg, text: '……嗯。', tip: '' };
      intro1._k = 0;
      intro2._k = 1;
      msgs = [intro1, intro2];
      S.shadow.msgs = [
        { role: 'sys', text: intro1.text, t: Date.now() },
        { role: 'ai', text: '……嗯。', t: Date.now() }
      ];
      storage.save(S);
    }
    this._msgSeq = msgs.length;
    this.setData({
      msgs,
      remain: util.fmtRemain(remain),
      leftToday: left,
      shadowName: S.shadow.name
    });
    /* 启动倒计时 */
    if (this._tyingTimer) clearInterval(this._tyingTimer);
    this._tyingTimer = setInterval(() => {
      const S2 = storage.load();
      const r = Math.max(0, shadow.SHADOW_MS - (Date.now() - (S2.shadow.sessionStart || Date.now())));
      this.setData({ remain: util.fmtRemain(r) });
      if (r <= 0) {
        this.endChat();
      }
    }, 1000);
    this.scrollChatToBottom();
  },

  fmtMsg(m) {
    if (m.role === 'sys') return { role: 'sys', text: m.text };
    if (m.role === 'ai')
      return { role: 'ai', avatar: this.data.agentImg, text: m.text, tip: m.tip || '' };
    return { role: 'me', text: m.text };
  },

  onChatInput(e) {
    this.setData({ text: e.detail.value });
  },

  onChatSend() {
    this.sendShadow(this.data.text);
  },

  sendShadow(raw) {
    const text = (raw || '').trim();
    if (!text) return;
    this.setData({ text: '' });
    const S = storage.load();
    S.shadow.msgs.push({ role: 'me', text, t: Date.now() });
    storage.save(S);
    this._userCount++;

    /* me 消息 + 打字占位一起 push 到页面，否则用户看不到自己发的字 */
    const meMsg = { role: 'me', text, _k: this._msgSeq++ };
    const typingMsg = {
      role: 'ai-temp',
      avatar: this.data.agentImg,
      text: '',
      _k: this._msgSeq++
    };
    const msgs = this.data.msgs.concat([meMsg, typingMsg]);
    this.setData({ msgs });
    this.scrollChatToBottom();

    const crisis = guardian.detectIntent(text) === 'crisis';
    /* v0.4.0 · 自我洞察：用户宣告检测 */
    const declaration = shadow.detectDeclaration(text);

    setTimeout(() => {
      /* 重新读取：setTimeout 闭包里的 S 是旧快照，用户连发几条时会互相覆盖丢消息 */
      const S2 = storage.load();
      const filtered = this.data.msgs.filter((m) => m.role !== 'ai-temp');
      if (crisis) {
        const text2 = guardian.CRISIS_TEXT;
        filtered.push({ role: 'ai', avatar: this.data.agentImg, text: text2, _k: this._msgSeq++ });
        S2.shadow.msgs.push({ role: 'ai', text: text2, t: Date.now() });
        storage.save(S2);
        this.setData({
          msgs: filtered,
          crisis: true,
          crisisText:
            '· 全国 24 小时心理援助热线：400-161-9995\n' +
            '· 紧急情况请直接拨打 120 / 110\n\n' +
            '影子接不住这么重的痛苦。但小白在乎你，你身边的人也在。'
        });
      } else if (declaration) {
        /* 自我洞察触发（用户宣告） */
        S2.shadow.observation = S2.shadow.observation || {};
        S2.shadow.observation.userSaidNotLikeTa = (S2.shadow.observation.userSaidNotLikeTa || 0) + 1;
        storage.save(S2);
        this.setData({ msgs: filtered });
        this.fireReveal({ reason: 'declaration' });
      } else {
        /* v0.4.0 · 把 affinity 传给 shadowReply */
        const reply = shadow.shadowReply(text, S2.shadow.profile, this.data.affinity);
        const tip =
          this._userCount > 0 && this._userCount % 3 === 0
            ? '提醒：这是AI生成的影子，不是真的TA。'
            : '';
        filtered.push({ role: 'ai', avatar: this.data.agentImg, text: reply, tip, _k: this._msgSeq++ });
        S2.shadow.msgs.push({ role: 'ai', text: reply, tip, t: Date.now() });
        storage.save(S2);
        this.setData({ msgs: filtered });
      }
      this.scrollChatToBottom();
    }, 800 + Math.random() * 900);
  },

  /* v0.4.0 · 触发自我洞察面板 */
  fireReveal(reasonObj) {
    const S = storage.load();
    if (this._tyingTimer) { clearInterval(this._tyingTimer); this._tyingTimer = null; }
    S.shadow.sessionStart = 0;
    S.shadow.revealTriggered = true;
    S.shadow.revealSeenAt = Date.now();
    S.shadow.revealReason = (reasonObj && reasonObj.reason) || 'manual';
    storage.save(S);
    this.setData({
      mode: 'view',
      sessionEnd: false,
      showReveal: true,
      reveal: {
        reason: S.shadow.revealReason,
        text: shadow.REVEAL_TRIGGERS.REVEAL_TEXT,
        secondary: shadow.REVEAL_TRIGGERS.REVEAL_SECONDARY,
        options: shadow.REVEAL_TRIGGERS.REVEAL_OPTIONS.slice()
      }
    });
  },

  /* v0.4.0 · 用户主动问「你用了这么久…有啥发现吗」 */
  onRevealManual() {
    const S = storage.load();
    /* 已经触发过并关闭 → 允许再看一次（而不是误报「还不到时候」） */
    if (S.shadow.revealTriggered) {
      this.setData({
        showReveal: true,
        reveal: {
          reason: S.shadow.revealReason || 'manual',
          text: shadow.REVEAL_TRIGGERS.REVEAL_TEXT,
          secondary: shadow.REVEAL_TRIGGERS.REVEAL_SECONDARY,
          options: shadow.REVEAL_TRIGGERS.REVEAL_OPTIONS.slice()
        }
      });
      return;
    }
    if (!shadow.manualReveal(S.shadow)) {
      wx.showToast({ title: '还不到时候，继续用一段时间吧', icon: 'none' });
      return;
    }
    this.fireReveal({ reason: 'manual' });
  },

  /* v0.4.0 · 关闭洞察面板 */
  onRevealDismiss() {
    this.setData({ showReveal: false, reveal: null });
    this.refresh();
  },

  /* v0.4.0 · 跳到洞察后的去向 */
  onRevealOption(e) {
    const opt = e.currentTarget.dataset.opt;
    if (!opt) return;
    this.setData({ showReveal: false, reveal: null });
    if (opt.mode === 'switchTab') {
      wx.switchTab({ url: opt.target });
    } else if (opt.mode === 'navigateTo') {
      wx.navigateTo({ url: opt.target });
    }
  },

  endChat() {
    if (this._tyingTimer) {
      clearInterval(this._tyingTimer);
      this._tyingTimer = null;
    }
    const S = storage.load();
    S.shadow.sessionStart = 0;
    storage.save(S);
    this.setData({ sessionEnd: true });
  },

  onSessionEndChat() {
    this.setData({ sessionEnd: false, mode: 'view' });
    this.refresh();
  },

  onSessionEndToGuardian() {
    this.setData({ sessionEnd: false, mode: 'view' });
    wx.switchTab({ url: '/pages/xiaobai/xiaobai' });
  },

  onCloseCrisis() {
    this.setData({ crisis: false, crisisText: '' });
  },

  /* wxml 里 catchtap="noop" 的空处理器（弹窗内层阻止冒泡用） */
  noop() {},

  scrollChatToBottom() {
    setTimeout(() => {
      wx.pageScrollTo({ scrollTop: 99999, duration: 100 });
    }, 30);
  }
});
